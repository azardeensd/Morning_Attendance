import React from 'react';
import AttendanceDashboard from './pages/AttendanceDashboard';
import './App.css';

function App() {
    return (
        <div className="App">
            <AttendanceDashboard />
        </div>
    );
}

export default App;
