import React, { useState, useEffect } from 'react';
import supabase from '../services/auth';
import './AttendanceDashboard.css';

const AttendanceDashboard = () => {
    const [attendanceData, setAttendanceData] = useState({
        daily: [],
        weekly: [],
        summary: {
            totalHeadCount: 0,
            totalPresent: 0,
            totalAbsent: 0,
            attendancePercentage: 0
        }
    });
    const [filter, setFilter] = useState('daily');
    const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
    const [loading, setLoading] = useState(false);
    const [currentTime, setCurrentTime] = useState(new Date());

    // Update current time every second
    useEffect(() => {
        const timer = setInterval(() => {
            setCurrentTime(new Date());
        }, 1000);
        return () => clearInterval(timer);
    }, []);

    // Fetch attendance data
    useEffect(() => {
        fetchAttendanceData();
    }, [filter, selectedDate]);

    const fetchAttendanceData = async () => {
        setLoading(true);
        try {
            if (filter === 'daily') {
                await fetchDailyAttendance();
            } else {
                await fetchWeeklyAttendance();
            }
        } catch (error) {
            console.error('Error fetching attendance data:', {
                message: error.message,
                details: error.details,
                hint: error.hint,
                code: error.code
            });
            
            // Set empty data on error
            setAttendanceData({
                daily: [],
                weekly: [],
                summary: {
                    totalHeadCount: 0,
                    totalPresent: 0,
                    totalAbsent: 0,
                    attendancePercentage: 0
                }
            });
        } finally {
            setLoading(false);
        }
    };

    const fetchDailyAttendance = async () => {
        try {
            // Get total employees count - REMOVED is_active filter since column doesn't exist
            const { count: totalHeadCount, error: countError } = await supabase
                .from('employees')
                .select('*', { count: 'exact' });
                // Removed: .eq('is_active', true); - since column doesn't exist

            if (countError) {
                console.error('Count error:', countError);
                throw countError;
            }

            // Get today's attendance
            const { data: dailyData, error: dailyError } = await supabase
                .from('attendance')
                .select('*')
                .eq('check_in_date', selectedDate)
                .order('check_in_time', { ascending: false });

            if (dailyError) {
                console.error('Daily data error:', dailyError);
                throw dailyError;
            }

            const totalPresent = dailyData?.length || 0;
            const totalAbsent = (totalHeadCount || 0) - totalPresent;
            const attendancePercentage = totalHeadCount > 0 ? 
                Math.round((totalPresent / totalHeadCount) * 100) : 0;

            setAttendanceData({
                daily: dailyData || [],
                weekly: [],
                summary: {
                    totalHeadCount: totalHeadCount || 0,
                    totalPresent,
                    totalAbsent,
                    attendancePercentage
                }
            });
        } catch (error) {
            console.error('Error in fetchDailyAttendance:', error);
            throw error;
        }
    };

    const fetchWeeklyAttendance = async () => {
        try {
            const selectedDateObj = new Date(selectedDate);
            
            // Calculate start of week (Monday)
            const startOfWeek = new Date(selectedDateObj);
            startOfWeek.setDate(selectedDateObj.getDate() - selectedDateObj.getDay() + 1);
            startOfWeek.setHours(0, 0, 0, 0);
            
            // Calculate end of week (Sunday)
            const endOfWeek = new Date(startOfWeek);
            endOfWeek.setDate(startOfWeek.getDate() + 6);
            endOfWeek.setHours(23, 59, 59, 999);

            // Get total employees count - REMOVED is_active filter
            const { count: totalHeadCount, error: countError } = await supabase
                .from('employees')
                .select('*', { count: 'exact' });
                // Removed: .eq('is_active', true); - since column doesn't exist

            if (countError) {
                console.error('Count error:', countError);
                throw countError;
            }

            // Get weekly attendance summary
            const { data: weeklyData, error: weeklyError } = await supabase
                .from('attendance')
                .select('check_in_date')
                .gte('check_in_date', startOfWeek.toISOString().split('T')[0])
                .lte('check_in_date', endOfWeek.toISOString().split('T')[0]);

            if (weeklyError) {
                console.error('Weekly data error:', weeklyError);
                throw weeklyError;
            }

            // Process weekly data
            const weeklySummary = [];
            const currentDate = new Date(startOfWeek);
            
            while (currentDate <= endOfWeek) {
                const dateStr = currentDate.toISOString().split('T')[0];
                const dayAttendance = (weeklyData || []).filter(record => record.check_in_date === dateStr);
                
                weeklySummary.push({
                    date: dateStr,
                    present: dayAttendance.length,
                    total: totalHeadCount || 0,
                    absent: (totalHeadCount || 0) - dayAttendance.length
                });
                
                currentDate.setDate(currentDate.getDate() + 1);
            }

            // Get today's attendance for the list view
            const { data: dailyData, error: dailyError } = await supabase
                .from('attendance')
                .select('*')
                .eq('check_in_date', selectedDate)
                .order('check_in_time', { ascending: false });

            if (dailyError) {
                console.error('Daily data error:', dailyError);
                throw dailyError;
            }

            const totalPresent = dailyData?.length || 0;
            const totalAbsent = (totalHeadCount || 0) - totalPresent;
            const attendancePercentage = totalHeadCount > 0 ? 
                Math.round((totalPresent / totalHeadCount) * 100) : 0;

            setAttendanceData({
                daily: dailyData || [],
                weekly: weeklySummary,
                summary: {
                    totalHeadCount: totalHeadCount || 0,
                    totalPresent,
                    totalAbsent,
                    attendancePercentage
                }
            });
        } catch (error) {
            console.error('Error in fetchWeeklyAttendance:', error);
            throw error;
        }
    };

    // Calculate attendance by hour for the stack chart
    const getHourlyAttendance = () => {
        if (filter === 'weekly') return [];
        
        const hourlyData = Array.from({ length: 13 }, (_, i) => {
            const hour = i + 7; // From 7 AM to 7 PM
            const hourStr = `${hour.toString().padStart(2, '0')}:00`;
            const count = attendanceData.daily.filter(record => {
                if (!record.check_in_time) return false;
                const recordHour = new Date(record.check_in_time).getHours();
                return recordHour === hour;
            }).length;
            
            return { hour: hourStr, count };
        });
        
        return hourlyData;
    };

    const hourlyAttendance = getHourlyAttendance();
    const maxAttendance = Math.max(...hourlyAttendance.map(h => h.count), 1);

    return (
        <div className="dashboard-container">
            {/* Header */}
            <div className="dashboard-header">
                <h1>Morning Meeting Attendance Dashboard</h1>
                <div className="current-time">
                    {currentTime.toLocaleTimeString()} | {currentTime.toLocaleDateString()}
                </div>
            </div>

            {/* Filters */}
            <div className="filters-container">
                <div className="filter-group">
                    <label>View:</label>
                    <select 
                        value={filter} 
                        onChange={(e) => setFilter(e.target.value)}
                        className="filter-select"
                    >
                        <option value="daily">Daily</option>
                        <option value="weekly">Weekly</option>
                    </select>
                </div>
                
                <div className="filter-group">
                    <label>Date:</label>
                    <input
                        type="date"
                        value={selectedDate}
                        onChange={(e) => setSelectedDate(e.target.value)}
                        className="date-input"
                    />
                </div>
                
                <button 
                    onClick={fetchAttendanceData}
                    disabled={loading}
                    className="refresh-btn"
                >
                    {loading ? '🔄 Refreshing...' : '🔄 Refresh'}
                </button>
            </div>

            {/* Summary Cards */}
            <div className="summary-cards">
                <div className="summary-card total">
                    <div className="card-icon">👥</div>
                    <div className="card-content">
                        <h3>Total Head Count</h3>
                        <span className="card-value">{attendanceData.summary.totalHeadCount}</span>
                    </div>
                </div>
                
                <div className="summary-card present">
                    <div className="card-icon">✅</div>
                    <div className="card-content">
                        <h3>Total Present</h3>
                        <span className="card-value">{attendanceData.summary.totalPresent}</span>
                    </div>
                </div>
                
                <div className="summary-card absent">
                    <div className="card-icon">❌</div>
                    <div className="card-content">
                        <h3>Total Absent</h3>
                        <span className="card-value">{attendanceData.summary.totalAbsent}</span>
                    </div>
                </div>
                
                <div className="summary-card percentage">
                    <div className="card-icon">📊</div>
                    <div className="card-content">
                        <h3>Attendance %</h3>
                        <span className="card-value">{attendanceData.summary.attendancePercentage}%</span>
                    </div>
                </div>
            </div>

            <div className="dashboard-content">
                {/* Stack Chart - Left Side */}
                <div className="chart-container">
                    <h2>Attendance Trend {filter === 'daily' ? '(Today)' : '(This Week)'}</h2>
                    
                    {filter === 'daily' ? (
                        <div className="stack-chart">
                            <div className="chart-title">Hourly Attendance Distribution (09:20 AM - 09:45 AM)</div>
                            <div className="chart-bars">
                                {hourlyAttendance.slice(2, 5).map((hourData, index) => ( // 09:00 to 09:45
                                    <div key={index} className="chart-bar-container">
                                        <div className="bar-label">{hourData.hour}</div>
                                        <div className="bar-wrapper">
                                            <div 
                                                className="attendance-bar"
                                                style={{
                                                    height: `${(hourData.count / maxAttendance) * 100}%`,
                                                    backgroundColor: hourData.count > 0 ? 
                                                        `hsl(${210 + (hourData.count * 10)}, 70%, 50%)` : '#e0e0e0'
                                                }}
                                            >
                                                <span className="bar-count">{hourData.count}</span>
                                            </div>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    ) : (
                        <div className="weekly-chart">
                            <div className="chart-title">Weekly Attendance Trend</div>
                            <div className="weekly-bars">
                                {attendanceData.weekly.map((dayData, index) => (
                                    <div key={index} className="weekly-bar-container">
                                        <div className="bar-label">
                                            {new Date(dayData.date).toLocaleDateString('en-US', { weekday: 'short' })}
                                        </div>
                                        <div className="weekly-bar-wrapper">
                                            <div 
                                                className="weekly-bar"
                                                style={{
                                                    height: `${(dayData.present / dayData.total) * 100}%`,
                                                    backgroundColor: dayData.present > 0 ? 
                                                        `hsl(${120 + (index * 40)}, 70%, 50%)` : '#e0e0e0'
                                                }}
                                            >
                                                <span className="bar-count">{dayData.present}/{dayData.total}</span>
                                            </div>
                                        </div>
                                        <div className="date-label">
                                            {new Date(dayData.date).getDate()}
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}
                </div>

                {/* Attendance List - Right Side */}
                <div className="attendance-list-container">
                    <h2>
                        {filter === 'daily' ? "Today's Attendance" : "Weekly Summary"} 
                        <span className="record-count">({attendanceData.daily.length} records)</span>
                    </h2>
                    
                    <div className="attendance-list">
                        {attendanceData.daily.length === 0 ? (
                            <div className="no-data">No attendance records found</div>
                        ) : (
                            <table className="attendance-table">
                                <thead>
                                    <tr>
                                        <th>Employee ID</th>
                                        <th>Name</th>
                                        <th>Department</th>
                                        <th>Check-in Time</th>
                                        <th>Rating</th>
                                        <th>Distance</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {attendanceData.daily.map((record, index) => (
                                        <tr key={record.id || index} className={index % 2 === 0 ? 'even' : 'odd'}>
                                            <td>{record.employee_id}</td>
                                            <td>{record.employee_name}</td>
                                            <td>{record.department_name}</td>
                                            <td>
                                                {record.check_in_time ? 
                                                    new Date(record.check_in_time).toLocaleTimeString('en-US', {
                                                        hour: '2-digit',
                                                        minute: '2-digit',
                                                        second: '2-digit'
                                                    }) : 'N/A'
                                                }
                                            </td>
                                            <td>
                                                <span className={`rating rating-${record.rating}`}>
                                                    {'★'.repeat(record.rating)}
                                                </span>
                                            </td>
                                            <td>{record.distance}m</td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default AttendanceDashboard;